#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void main() {
  char str[100];
  while(fgets(str, sizeof(str), stdin)) {
    if (strcmp(str, "exit\n")==0) {
      break;
    }
    printf(str);
    fflush(stdout);
  }
  exit(0);
}
