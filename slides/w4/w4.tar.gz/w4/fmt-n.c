#include <stdio.h>

void main(){
  int a1, a2, a3, a4;
  printf("AAAABBBB%n\n", &a1);
  printf("%d%n\n", a1, &a2);
  printf("%100c%n\n", a1, &a3);
  printf("%08x %1$n %d\n", &a4, a3);

  printf("\n%d %d %d %d\n", a1, a2, a3, a4);
}
