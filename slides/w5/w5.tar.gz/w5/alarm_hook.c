unsigned int alarm(unsigned int x) {
  return 0;
}
