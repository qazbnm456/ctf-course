#include <stdio.h>

/*
 * perl -e 'print "\xeb\xfe","A"x82,"\x6f\x85\x04\x08","\n"' > in
 */

int output(int len, char *str) {
  char buf[80];
  while (len--) {
    buf[len] = str[len];
    if (buf[len]==' ') buf[len] = '_';
  }
  return 0;
}

int main() {
  char str[0x80];
  fgets(str, sizeof(str), stdin);
  output(strlen(str)-1, str);
}
